<?php

namespace Common\Channels;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class CrupdateChannelRequest extends FormRequest
{
    public function rules(): array
    {
        $required = $this->getMethod() === 'POST' ? 'required' : '';
        $ignore =
            $this->getMethod() === 'PUT' ? $this->route('channel')->id : '';

        return [
            'name' => [
                $required,
                'string',
                'min:3',
                'max:100',
                Rule::unique('channels')
                    ->ignore($ignore)
                    ->when(
                        $this->get('type') === 'list' && $this->has('user_id'),
                        fn($query) => $query->where(
                            'user_id',
                            $this->get('user_id'),
                        ),
                    ),
            ],
            'description' => 'nullable|string|max:500',
            'public' => 'boolean',
            'content.data' => 'array',
            'config' => 'array',
            'type' => 'string',
            'config.autoUpdateMethod' =>
                'required_if:config.contentType,autoUpdate',
        ];
    }

    public function messages()
    {
        return [
            'config.autoUpdateMethod' => __('Auto update method is required.'),
        ];
    }
}
